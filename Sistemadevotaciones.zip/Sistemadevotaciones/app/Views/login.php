<?= $this->extend('plantilla') ?>
<?= $this->section('content') ?>

<head>
    <!-- Íconos de FontAwesome y estilos personalizados -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-/1xvAq3XU6wvE3xj/3eJk4NMQMkFMEGLG5NhtlZfXUUSswtdCzZg3UkkAq8U67O1YiUvIcSxwbFzJb9zqzRJLw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <head>
        <!-- Incluye la librería de SweetAlert -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.26/dist/sweetalert2.min.css">
    </head>

    <style>
        .gradient-custom-2 {
            background: linear-gradient(to right, #2c5364, #203a43, #0f2027);
        }

        @media (min-width: 768px) {
            .gradient-form {
                height: 100vh !important;
            }
        }

        @media (min-width: 769px) {
            .gradient-custom-2 {
                border-top-right-radius: .3rem;
                border-bottom-right-radius: .3rem;
            }
        }

        .btn-voto {
            background-color: #28a745;
            color: white;
        }

        .btn-voto:hover {
            background-color: #218838;
        }

        .btn-outline-register {
            border-color: white;
            color: white;
        }

        .btn-outline-register:hover {
            background-color: white;
            color: #0f2027;
        }
    </style>
</head>

<section class="h-100 gradient-form" style="background-color: #eee;">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-xl-10">
                <div class="card rounded-3 text-black shadow">
                    <div class="row g-0">
                        <!-- Formulario de acceso -->
                        <div class="col-lg-6">
                            <div class="card-body p-md-5 mx-md-4">
                                <div class="text-center">
                                    <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                                        style="width: 130px;" alt="logo votaciones">
                                    <h4 class="mt-3 mb-4 pb-1">Sistema de Votaciones Estudiantiles</h4>
                                </div>

                                <form action="<?= base_url('/Sistemadevotaciones/public/index.php/Home/ingreso') ?>" method="POST">
                                    <p class="mb-4">Inicia sesión para acceder a tu voto</p>

                                    <div class="form-outline mb-4">
                                        <label class="form-label" for="usuario"><i class="fas fa-user"></i> Usuario</label>
                                        <input type="text" id="usuario" name="usuario" class="form-control" placeholder="Carnet o correo" required />
                                    </div>

                                    <div class="form-outline mb-4">
                                        <label class="form-label" for="clave"><i class="fas fa-lock"></i> Contraseña</label>
                                        <input type="password" id="clave" name="pass" class="form-control" required />
                                    </div>

                                    <div class="text-center pt-1 mb-5 pb-1">
                                        <button class="btn btn-voto btn-block fa-lg gradient-custom-2 mb-3" type="submit">
                                            <i class="fas fa-check-circle"></i> Ingresar
                                        </button>
                                        <br>
                                        <a class="text-muted" href="#">¿Olvidaste tu contraseña?</a>
                                    </div>
                                </form>

                            </div>
                        </div>

                        <!-- Lado informativo -->
                        <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                            <div class="text-white px-3 py-4 p-md-5 mx-md-4">
                                <h4 class="mb-4"><i class="fas fa-vote-yea"></i> ¡Tu voto cuenta!</h4>
                                <p class="small mb-0">
                                    Bienvenido al sistema de votaciones estudiantiles de nuestra institución.
                                    Aquí podrás ejercer tu derecho a elegir a tus representantes de forma
                                    segura, rápida y transparente. Ingresa con tus credenciales y participa
                                    activamente en la toma de decisiones de tu comunidad académica.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Script de SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.26/dist/sweetalert2.all.min.js"></script>

<!-- Verifica si hay un mensaje de error y muestra el alert -->
<?php if (!empty($mensaje)): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: '¡Error!',
            text: '<?= $mensaje ?>',
            confirmButtonText: 'Cerrar'
        });
    </script>
<?php endif; ?>

<?= $this->endSection() ?>
