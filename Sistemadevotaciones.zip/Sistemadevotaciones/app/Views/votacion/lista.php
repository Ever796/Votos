<?= $this->extend('plantilla'); ?>
<?= $this->section('content'); ?>

<!-- FontAwesome CDN (puedes moverlo a tu plantilla base para evitar repetirlo) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<div class="container mt-5">

    <!-- Título -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-primary">
            <i class="fas fa-users"></i> Lista de Candidatos
        </h2>
    </div>

    <!-- Alerta de éxito -->
    <?php if (session()->getFlashdata('mensaje')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?= session()->getFlashdata('mensaje') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
    <?php endif; ?>

    <hr>
    <a href="<?=base_url('/Sistemadevotaciones/public/index.php/votacion/resultado')?>" class="btn btnsuccess">RESULTADOS</a>
    <!-- Tabla de candidatos -->
    <div class="table-responsive shadow rounded">
        <table class="table table-hover align-middle mb-0 table-bordered">
            <thead class="table-primary text-center">
                <tr>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Género</th>
                    <th>Carnet</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($todos as $data): ?>
                    <tr class="text-center">
                        <td><?= esc($data->nombre) ?></td>
                        <td><?= esc($data->apellido) ?></td>
                        <td><?= esc($data->genero) ?></td>
                        <td><?= esc($data->carnet) ?></td>
                        <td>
                            <a href="<?= base_url('/Sistemadevotaciones/public/index.php/votacion/votar/' . $data->id_alumno_rol) ?>"
                                class<?php if(!$mivoto): ?>
<a href="<?=base_url('/index.php/votacion/votar/'.$data->id_alumno_rol) 
?>"class="btn btn-success">Votar</a>
<?php endif ?>
                            <a href="<?= base_url('/Sistemadevotaciones/public/index.php/votacion/eliminarcandidato/' . $data->id_alumno_rol) ?>"
                                class="btn btn-outline-danger btn-sm"
                                onclick="return confirm('¿Estás seguro de eliminar este candidato?')" title="Eliminar">
                                <i class="fas fa-trash-alt"></i> Eliminar
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Botón Volver Atrás -->
    <div class="mt-4">
        <a href="javascript:history.back()" class="btn btn-danger">
            <i class="fas fa-arrow-left me-2"></i> Volver atrás
        </a>
    </div>
    <?php if($mivoto): ?>
<h4 class="text-danger">Ud ya emitio su voto</h4>
<?php endif ?>
</div>

<?= $this->endSection(); ?>