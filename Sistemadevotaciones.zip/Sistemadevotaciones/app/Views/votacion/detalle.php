<?= $this->extend('plantilla'); ?>
<?= $this->section('content'); ?>
<h4 class="text-success">Candidato: <?= $candidato->nombre ?> <?= $candidato->apellido 
?></h4>
<table>
<thead>
<tr>
<th>Nombre</th>
<th>Apellido</th> 
<th>Fecha</th>
</tr>
</thead>
<tbody>
<?php foreach($votos as $data): ?>
<tr>
<td><?= $data->nombre ?></td>
<td><?= $data->apellido ?></td>
<td><?= $data->fecha ?></td> 
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?= $this->endsection(); ?>