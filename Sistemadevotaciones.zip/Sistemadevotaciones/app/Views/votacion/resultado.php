<?= $this->extend('plantilla'); ?>
<?= $this->section('content'); ?>

<h4 class="text-success text-center mb-5">Resultados de las Votaciones</h4>

<div class="table-container">
    <table class="table table-striped table-bordered table-hover table-sm">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th># Votos</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($total as $data): ?>
            <tr>
                <td><?= esc($data->nombre) ?></td>
                <td><?= esc($data->apellido) ?></td>
                <td><?= esc($data->votos) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= $this->endSection(); ?>

<style>
    /* Contenedor de la tabla */
    .table-container {
        margin: 50px auto;
        padding: 20px;
        max-width: 80%;
        background-color: #fff;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        overflow: hidden;
        animation: slideIn 1s ease-out;
    }

    /* Animación de entrada */
    @keyframes slideIn {
        0% {
            transform: translateY(-50px);
            opacity: 0;
        }
        100% {
            transform: translateY(0);
            opacity: 1;
        }
    }

    /* Media Queries para hacer la tabla responsiva */
    @media (max-width: 768px) {
        .table-container {
            max-width: 95%;
        }
        h4 {
            font-size: 1.5rem;
        }
    }
</style>
