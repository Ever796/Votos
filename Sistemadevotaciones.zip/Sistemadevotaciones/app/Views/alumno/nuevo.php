<?= $this->extend('plantilla') ?>
<?= $this->section('content') ?>

<!-- Contenedor con margen superior e inferior -->
<div class="container my-5">
    <!-- Título para el formulario -->
    <h2 class="text-center mb-5 text-primary font-weight-bold">Registro de Alumno</h2>

    <!-- Formulario -->
    <form method="post" action="<?= base_url('/Sistemadevotaciones/public/index.php/alumno/guardar') ?>" class="form-container shadow-sm p-4 rounded-lg bg-light">

        <!-- Campo para el nombre -->
        <div class="form-group mb-4">
            <label for="nombre" class="form-label text-muted">Nombre</label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                </div>
                <input type="text" class="form-control form-control-lg" name="nombre" placeholder="Ingrese su nombre" required>
            </div>
        </div>

        <!-- Campo para el apellido -->
        <div class="form-group mb-4">
            <label for="apellido" class="form-label text-muted">Apellido</label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                </div>
                <input type="text" class="form-control form-control-lg" name="apellido" placeholder="Ingrese su apellido" required>
            </div>
        </div>

        <!-- Campo para el carnet -->
        <div class="form-group mb-4">
            <label for="carnet" class="form-label text-muted">Carnet</label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                </div>
                <input type="text" class="form-control form-control-lg" name="carnet" placeholder="Ingrese su carnet" required>
            </div>
        </div>

        <!-- Campo para seleccionar el género -->
        <div class="form-group mb-4">
            <label for="genero" class="form-label text-muted">Género</label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-venus-mars"></i></span>
                </div>
                <select class="form-control form-control-lg" name="genero" required>
                    <option value="Femenino">Femenino</option>
                    <option value="Masculino">Masculino</option>
                </select>
            </div>
        </div>

        <!-- Campo para la contraseña -->
        <div class="form-group mb-4">
            <label for="pass" class="form-label text-muted">Contraseña</label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                </div>
                <input type="password" class="form-control form-control-lg" id="pass" name="pass" required>
            </div>
        </div>

        <!-- Botones de acción (Guardar y Volver) -->
        <div class="d-flex justify-content-between mt-4">
            <button type="submit" class="btn btn-success btn-lg px-4 py-3 rounded-pill text-white">
                <i class="fas fa-check-circle"></i> Guardar
            </button>
            <a href="<?= base_url('/Sistemadevotaciones/public/index.php/alumno/index') ?>" class="btn btn-danger btn-lg px-4 py-3 rounded-pill">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
        </div>

    </form>
    <?php if (session()->getFlashdata('message')): ?>
<script>
    Swal.fire({
        title: '¡Éxito!',
        text: '<?= session()->getFlashdata('message') ?>',
        icon: 'success',
        confirmButtonText: 'Cerrar'
    });
</script>


<?php endif; ?>
</div>

<style>
    /* Estilo general del contenedor del formulario */
    .form-container {
        max-width: 600px;
        margin: 0 auto;
    }

    /* Fondo claro con sombra sutil */
    .bg-light {
        background-color: #f8f9fa;
    }

    /* Bordes suaves para los campos de entrada */
    .form-control {
        border-radius: 8px;
        padding: 1rem;
        font-size: 1.1rem;
    }

    /* Estilo para los campos cuando están enfocados */
    .form-control:focus {
        border-color: #28a745;
        box-shadow: 0 0 10px rgba(40, 167, 69, 0.3);
        outline: none;
    }

    /* Título centrado con color primario */
    h2 {
        color: #007bff;
        font-weight: bold;
        font-size: 2rem;
    }

    /* Estilo del botón de guardar */
    .btn-success {
        background-color: #28a745;
        border: none;
        border-radius: 25px;
        transition: background-color 0.3s ease-in-out;
    }

    /* Efecto de hover para el botón */
    .btn-success:hover {
        background-color: #218838;
    }

    /* Estilo del botón de volver */
    .btn-danger {
        background-color: #dc3545;
        border: none;
        border-radius: 25px;
        transition: background-color 0.3s ease-in-out;
    }

    /* Efecto de hover para el botón de volver */
    .btn-danger:hover {
        background-color: #c82333;
    }

    /* Sombra sutil para el formulario */
    .shadow-sm {
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }

    /* Iconos dentro de los inputs */
    .input-group-text {
        background-color: #f1f1f1;
        border-right: none;
    }

    /* Alineación de los botones en la misma fila */
    .d-flex {
        display: flex;
        justify-content: space-between;
    }

    /* Espaciado entre los botones */
    .btn {
        width: 48%;
    }
</style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?= $this->endSection() ?>
