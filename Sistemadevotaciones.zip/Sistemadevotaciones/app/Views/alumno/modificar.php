<?= $this->extend('plantilla') ?>
<?= $this->section('content') ?>

<!-- Estilos CSS -->
<style>
    :root {
        --primary: #007bff;
        --primary-dark: #0056b3;
        --danger: #dc3545;
        --danger-dark: #b02a37;
        --bg-color: #f0f2f5;
        --card-bg: #ffffff;
        --text-color: #333;
        --border-radius: 12px;
    }

    body {
        background-color: var(--bg-color);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: var(--text-color);
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        /* Centra el contenido en la pantalla */
        flex-direction: column;
    }

    h2 {
        font-size: 2rem;
        font-weight: 700;
        text-align: center;
        color: var(--primary);
        margin-bottom: 30px;
    }

    .container {
        width: 100%;
        max-width: 600px;
        padding: 30px 20px;
        background: var(--card-bg);
        border-radius: var(--border-radius);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .formlabel {
        font-size: 1rem;
        font-weight: 600;
        color: var(--primary);
    }

    .form-control {
        padding: 10px;
        font-size: 1rem;
        border-radius: var(--border-radius);
        border: 1px solid #ddd;
        width: 100%;
        margin-top: 8px;
    }

    .form-control:focus {
        border-color: var(--primary);
        box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }

    .btn {
        font-size: 1rem;
        padding: 12px 20px;
        border-radius: var(--border-radius);
        text-align: center;
        transition: all 0.3s ease;
        cursor: pointer;
        width: 100%;
    }

    .btn-success {
        background-color: var(--primary);
        color: white;
        border: none;
    }

    .btn-success:hover {
        background-color: var(--primary-dark);
    }

    .btn-danger {
        background-color: var(--danger);
        color: white;
    }

    .btn-danger:hover {
        background-color: var(--danger-dark);
    }

    .mb-3 {
        margin-bottom: 1.5rem;
    }

    /* Estilo para los select */
    select.form-control {
        height: 45px;
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: var(--border-radius);
        padding: 0 12px;
    }

    .btn-red {
        background-color: #dc3545;
        color: white;
        border: 2px solid #dc3545;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .btn-red:hover {
        background-color: white;
        color: #dc3545;
        transform: scale(1.05);
    }
</style>

<!-- Formulario de modificación de alumno -->
<div class="container">
    <h2>Modificar Alumno</h2>
    <form method="post" action="<?= base_url('/Sistemadevotaciones/public/index.php/alumno/actualizar/' . $alumno->id) ?>">
        <div class="mb-3">
            <label for="nombre" class="formlabel">Nombre</label>
            <input type="text" class="form-control" name="nombre" placeholder="Nombre" value="<?= $alumno->nombre ?>">
        </div>
        <div class="mb-3">
            <label for="apellido" class="formlabel">Apellido</label>
            <input type="text" class="form-control" name="apellido" placeholder="Apellido" value="<?= $alumno->apellido ?>">
        </div>
        <div class="mb-3">
            <label for="carnet" class="formlabel">Carnet</label>
            <input type="text" class="form-control" name="carnet" placeholder="Carnet" value="<?= $alumno->carnet ?>">
        </div>
        <div class="mb-3">
            <label for="genero" class="formlabel">Género</label>
            <select class="form-control" name="genero">
                <option value="Femenino" <?php if ($alumno->genero == "Femenino") : ?>selected<?php endif ?>>Femenino</option>
                <option value="Masculino" <?php if ($alumno->genero == "Masculino") : ?>selected<?php endif ?>>Masculino</option>
            </select>
        </div>
        <div class="mb-3">
            <input type="submit" class="btn btn-success" value="Guardar">
        </div>
    </form>
    <div class="container" style="margin-top: 20px;">
        <a href="<?= base_url('/Sistemadevotaciones/public/index.php/alumno/index') ?>" class="btn btn-red">
            <i class="fas fa-arrow-left"></i> Volver
        </a>
    </div>
</div>

<?= $this->endSection() ?>