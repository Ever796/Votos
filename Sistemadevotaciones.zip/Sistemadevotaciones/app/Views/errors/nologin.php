<?= $this->extend('plantilla'); ?>
<?= $this->section('content'); ?>

<!-- Contenedor principal con fondo y estilo -->
<div class="error-container">
    <!-- Imagen de error opcional -->
    <img src="<?= base_url('system/Images/error.png') ?>" alt="Error Icon" class="error-icon">

    <!-- Mensaje de error en formato destacable -->
    <h1 class="error-title">¡Acceso Denegado!</h1>
    <p class="error-message">No tienes los permisos necesarios para acceder a esta pantalla. Si crees que esto es un error, por favor contacta con el administrador del sistema.</p>

    <!-- Botón de redirección o volver al inicio -->
    <a href="<?= base_url('inicio') ?>" class="btn-back">Volver al inicio</a>
</div>

<!-- Aquí van los estilos -->
<style>
    .error-container {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: 100vh;
        text-align: center;
        background-color: #f8d7da;
        border-radius: 8px;
        padding: 30px;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    }

    .error-icon {
        width: 100px;
        height: auto;
        margin-bottom: 20px;
    }

    .error-title {
        font-size: 2rem;
        color: #721c24;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .error-message {
        font-size: 1.2rem;
        color: #721c24;
        margin-bottom: 20px;
    }

    .btn-back {
        padding: 12px 20px;
        background-color: #0056b3;
        color: white;
        text-decoration: none;
        border-radius: 4px;
        font-size: 1rem;
        transition: background-color 0.3s;
    }

    .btn-back:hover {
        background-color: #003366;
    }
</style>

<?= $this->endSection(); ?>