    <?= $this->extend('plantilla') ?>
    <?= $this->section('content') ?>

    <?php
    $session = session();
    if (!$session->get('id')) {
        return view('errors/nologin');
    }
    ?>

    <!-- Enlace al CSS y a Font Awesome -->

    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" crossorigin="anonymous" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.26/dist/sweetalert2.min.css">
        <style>
            :root {
                --primary: #007bff;
                --primary-dark: #0056b3;
                --danger: #dc3545;
                --danger-dark: #b02a37;
                --bg-color: #f0f2f5;
                --card-bg: #ffffff;
                --text-color: #333;
                --border-radius: 16px;
            }

            body {
                background-color: var(--bg-color);
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                color: var(--text-color);
                margin: 0;
                padding: 0;
            }

            h2 {
                font-size: 2.2rem;
                font-weight: 700;
                text-align: center;
                color: var(--primary);
                position: relative;
                margin-bottom: 40px;
            }

            h2::after {
                content: '';
                width: 80px;
                height: 4px;
                background-color: var(--primary);
                position: absolute;
                bottom: -10px;
                left: 50%;
                transform: translateX(-50%);
                border-radius: 2px;
            }

            .container {
                max-width: 1100px;
                margin: auto;
                padding: 40px 20px;
                background: var(--card-bg);
                border-radius: var(--border-radius);
                box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08);
                animation: fadeIn 0.6s ease;
            }

            .btn {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                font-weight: 600;
                border: none;
                border-radius: 12px;
                padding: 10px 20px;
                text-decoration: none;
                transition: all 0.3s ease;
                box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
                cursor: pointer;
            }

            .btn-primary {
                background-color: var(--primary);
                color: white;
            }

            .btn-primary:hover {
                background-color: var(--primary-dark);
                transform: scale(1.05);
            }

            .btn-danger {
                background-color: var(--danger);
                color: white;
            }

            .btn-danger:hover {
                background-color: var(--danger-dark);
                transform: scale(1.05);
            }

            .btn-lg {
                font-size: 1rem;
                padding: 12px 28px;
            }

            .btn-sm {
                font-size: 0.85rem;
                padding: 6px 14px;
            }

            table {
                width: 100%;
                border-collapse: separate;
                border-spacing: 0;
                margin-top: 20px;
                background: white;
                border-radius: var(--border-radius);
                overflow: hidden;
                box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
            }

            th,
            td {
                padding: 16px;
                text-align: center;
            }

            th {
                background-color: var(--primary);
                color: white;
                text-transform: uppercase;
                font-size: 0.95rem;
                letter-spacing: 1px;
            }

            tr:nth-child(even) {
                background-color: #f9fafb;
            }

            tr:hover {
                background-color: #eef2f7;
                transition: 0.3s ease;
            }

            .text-end {
                text-align: end;
            }

            .my-5 {
                margin-top: 3rem;
                margin-bottom: 3rem;
            }

            .mb-3 {
                margin-bottom: 1rem;
            }

            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(15px);
                }

                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            @media (max-width: 768px) {
                h2 {
                    font-size: 1.6rem;
                }

                table,
                thead,
                tbody,
                th,
                td,
                tr {
                    font-size: 0.9rem;
                }

                .btn {
                    padding: 8px 14px;
                }

                .container {
                    padding: 20px;
                }
            }

            .btn-red {
                background-color: #e63946;
                color: #fff;
            }

            .btn-red:hover {
                background-color: #c82333;
                transform: scale(1.05);
            }

            .btn-candidato {
                background-color: #198754;
                /* verde Bootstrap */
                color: white;
                border: 2px solid #198754;
                transition: all 0.3s ease;
            }

            .btn-candidato:hover {
                background-color: white;
                color: #198754;
                transform: scale(1.05);
            }
        </style>
    </head>


    <!-- Contenedor de la página -->
<div class="container my-5">
    <div class="col-md-3 mb-4">
        <div style="background: #ffffff; border-left: 6px solid #007bff; padding: 15px 20px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);">
            <h5 style="margin: 0; font-weight: 600; color: #007bff;">
                <i class="fas fa-user-circle me-2"></i> Bienvenido/a
            </h5>
            <p style="margin: 4px 0 14px; font-size: 1rem; font-weight: 500; color: #333;">
                <?= $nombre ?>
            </p>
            <a href="<?= base_url('/Sistemadevotaciones/public/index.php/Home/index') ?>"
                class="btn btn-red"
                style="font-size: 1rem; padding: 10px 20px;">
                <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
            </a>
        </div>
    </div>

    <!-- Título de la página -->
    <h2 class="text-center mb-4">
        <i class="fas fa-users"></i> Lista de Alumnos
    </h2>

    <!-- Botón para agregar nuevo registro -->
    <div class="mb-3 text-end">
        <a href="<?= base_url('/Sistemadevotaciones/public/index.php/alumno/nuevo') ?>" class="btn btn-primary btn-lg">
            <i class="fas fa-user-plus"></i> Nuevo Registro
        </a>
        <a href="<?= base_url('/Sistemadevotaciones/public/index.php/votacion/index') ?>" class="btn btn-primary btn-lg">
            <i class="fas fa-users"></i> candidatos
        </a>
    </div>
    <br>

    <!-- Tabla de alumnos -->
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th><i class="fas fa-id-badge"></i> ID</th>
                <th><i class="fas fa-user"></i> Nombre</th>
                <th><i class="fas fa-user"></i> Apellido</th>
                <th><i class="fas fa-venus-mars"></i> Género</th>
                <th><i class="fas fa-id-card"></i> Carnet</th>
                <th><i class="fas fa-cogs"></i> Acciones</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($todos as $alumno): ?>
                <tr>
                    <td><?= $alumno->id ?></td>
                    <td><?= $alumno->nombre ?></td>
                    <td><?= $alumno->apellido ?></td>
                    <td><?= $alumno->genero ?></td>
                    <td><?= $alumno->carnet ?></td>
                    <td>
                        <div style="display: flex; flex-direction: column; gap: 6px; align-items: center;">
                            <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                <a href="<?= base_url('/Sistemadevotaciones/public/index.php/alumno/modificar/' . $alumno->id) ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit"></i> Modificar
                                </a>
                                <!-- Botón de eliminar con SweetAlert -->
                                <a href="javascript:void(0);" class="btn btn-danger btn-sm" onclick="eliminarAlumno(<?= $alumno->id ?>)">
                                    <i class="fas fa-trash-alt"></i> Eliminar
                                </a>
                                <a href="<?= base_url('/Sistemadevotaciones/public/index.php/alumno/proponer/' . $alumno->id) ?>"
                                    class="btn btn-candidato">
                                    <i class="fas fa-user-check me-1"></i> Candidato/a
                                </a>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<?php if (session()->getFlashdata('message')): ?>
<script>
    Swal.fire({
        title: '¡Éxito!',
        text: '<?= session()->getFlashdata('message') ?>',
        icon: 'success',
        confirmButtonText: 'Cerrar'
    });
</script>
<?php endif; ?>

<!-- Script para usar SweetAlert en la eliminación -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function eliminarAlumno(id) {
        Swal.fire({
            title: '¿Estás seguro?',
            text: "No podrás revertir esto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar!',
            cancelButtonText: 'Cancelar',
        }).then((result) => {
            if (result.isConfirmed) {
                // Redirigir a la acción de eliminar en PHP
                window.location.href = '<?= base_url('/Sistemadevotaciones/public/index.php/alumno/eliminar/') ?>' + id;
            }
        });
    }
</script>
    <?= $this->endSection() ?>