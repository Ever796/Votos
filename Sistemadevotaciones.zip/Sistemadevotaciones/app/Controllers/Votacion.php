<?php

namespace App\Controllers;

use App\Models\AlumnoModel;
use App\Models\AlumnoRolModel;
use App\Models\RolModel;
use App\Models\VotacionModel;

class Votacion extends BaseController
{
    // Método index
    public function index()
    {
        // Buscamos y validamos la sesión
        $session = session();
        if (!$session->get('id')) {
            return view('errors/nologin');
        }

        // Creo una variable para controlar si ya votó
        $yavoto = 0;
        $rolModel = new RolModel();

        // Asegúrate de que el nombre de la variable coincida
        $votacionModel = new VotacionModel();  // Asegúrate de usar "VotacionModel" con mayúscula "V"
        
        // Los candidatos se buscan con el modelo de rol
        $candidatos = $rolModel->buscarAlumnoXRol("CANDIDATO");
        
        // Hago la consulta a la tabla de votación con el id del usuario, si ya votó le digo a la vista que ya lo hizo
        $mivoto = $votacionModel->where("id_alumno = " . $session->get('id'))->first();  // Cambié a `first()` para obtener un solo resultado
        
        if ($mivoto) {
            $yavoto = 1;
        }
        
        $data = ['todos' => $candidatos, 'mivoto' => $yavoto];

        // Retorna la vista con los datos
        return view('votacion/lista', $data);
    }

    // Método para eliminar candidato
    public function eliminarcandidato($id_alumno_rol)
    {
        $session = session();
        if (!$session->get('id')) {
            return view('errors/nologin');
        }

        // Paso 1: eliminar las votaciones donde este candidato ha sido votado
        $votacionModel = new VotacionModel();
        $votacionModel->where('id_delegado', $id_alumno_rol)->delete();

        // Paso 2: eliminar el rol del alumno (candidato)
        $alumnoRolModel = new AlumnoRolModel();
        $alumnoRolModel->delete($id_alumno_rol);

        // Redirige a la página de votación con un mensaje de éxito
        return redirect()->to(base_url('/Sistemadevotaciones/public/index.php/votacion/index'))
            ->with('mensaje', 'Candidato eliminado correctamente');
    }

    public function votar($idcandidato){
        $session = session();
        if(!$session->get('id')){
        return view('errors/nologin');
        } 
        $votacion = new VotacionModel();
        $data=array(
        "id_delegado" => $idcandidato,
        "id_alumno" => $session->get('id'), 
        );
        $votacion->insert($data);
        return redirect()->to('http://localhost:8080/Sistemadevotaciones/public/index.php/Alumno/index');
        }


    public function resultado(){
        $session = session();
        if(!$session->get('id')){
        return view('errors/nologin');
        }
        $votacion = new VotacionModel();
        $votos = $votacion->resultadoVotacion();
        return view('votacion/resultado', ['total' => $votos]);
        }




        public function detalle($id_alumno){
            $session = session();
            if(!$session->get('id')){
            return view('errors/nologin');
            }
            $votacionModel = new VotacionModel();
            $alumnoModel = new AlumnoModel();
            $candidato = $alumnoModel->find($id_alumno);
            $votos = $votacionModel->detalleVotacion($id_alumno);
            $data=[
            'votos' => $votos,
            'candidato' => $candidato
            ];
            return view('votacion/detalle', $data);
            }
            



}
