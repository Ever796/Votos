<?php

namespace App\Controllers;

use App\Models\AlumnoModel;
use App\Models\AlumnoRolModel;
use App\Models\RolModel;



class Alumno extends BaseController
{

    public function index(): string
    {
        $session = session();
        if (!$session->get('id')) {
            return view('errors/nologin');
        }
        $alumnoModel = new AlumnoModel();
        $datos = $alumnoModel->findAll();
        $datos = array(
            "todos" => $datos,
            "nombre" => $session->get('usuario'),
            "admin" => $session->get('admin'),
        );
        return view('inicio', $datos);
    }



    public function nuevo(): string
    {
        $session = session();
        if (!$session->get('id')) {
            return view('errors/nologin');
        }
        return view('alumno/nuevo');
    }



    public function guardar()
    {
        $session = session();
        if (!$session->get('id')) {
            return view('errors/nologin');
        }

        $alumnoModel = new AlumnoModel();

        $passPlano = $this->request->getPost('pass');
        $passEncriptado = password_hash($passPlano, PASSWORD_DEFAULT);

        $data = array(
            'nombre' => $this->request->getPost('nombre'),
            'apellido' => $this->request->getPost('apellido'),
            'genero' => $this->request->getPost('genero'),
            'carnet' => $this->request->getPost('carnet'),
            'pass' => $passEncriptado
        );

        $alumnoModel->insert($data);

        // Redirigir con mensaje de éxito
        return redirect()->to('http://localhost:8080/Sistemadevotaciones/public/index.php/alumno/index')->with('message', 'Alumno agregado correctamente');
    }



    public function modificar($id)
    {
        $session = session();
        if (!$session->get('id')) {
            return view('errors/nologin');
        }
        $alumnoModel = new AlumnoModel();
        $alumno = $alumnoModel->find($id);
        $data = array('alumno' => $alumno);
        return view('Alumno/modificar', $data);
    }


    public function actualizar($id)
    {
        $session = session();
        if (!$session->get('id')) {
            return view('errors/nologin');
        }
        $alumnoModel = new AlumnoModel();
        $data = array(
            'nombre' => $this->request->getPost('nombre'),
            'apellido' => $this->request->getPost('apellido'),
            'genero' => $this->request->getPost('genero'),
            'carnet' => $this->request->getPost('carnet'),
        );
        $alumnoModel->update($id, $data);
        return redirect()->to('http://localhost:8080/Sistemadevotaciones/public/index.php/alumno/index');
    }



    public function eliminar($id)
{
    $session = session();
    if (!$session->get('id')) {
        return view('errors/nologin');
    }
    
    $alumnoModel = new AlumnoModel();
    $alumnoModel->delete($id);
    
    // Redirigir con mensaje de éxito
    $session->setFlashdata('message', 'Alumno eliminado correctamente');
    return redirect()->to('http://localhost:8080/Sistemadevotaciones/public/index.php/alumno/index');
}


    
    public function proponer($id)
    {
        $alumnorolModel = new AlumnoRolModel();
        $rolModel = new RolModel();
        //buscamos el rol primero
        $candidato = $rolModel->where("nombre = 'CANDIDATO' ")->first();
        $data = array(
            'id_alumno' => $id,
            'id_rol' => $candidato->id,
        );
        $alumnorolModel->insert($data);
        return redirect()->to('http://localhost:8080/Sistemadevotaciones/public/index.php/votacion/index');
    }
}
