<?php
namespace App\Models;
use CodeIgniter\Model;
class votacionModel extends Model
{
protected $table = 'votacion';
protected $primaryKey = 'id';
protected $useAutoIncrement = true;
protected $returnType = 'object';
protected $useSoftDeletes = false;
protected $allowedFields = ['id_alumno','fecha','id_delegado'];
protected bool $allowEmptyInserts = false;
protected bool $updateOnlyChanged = true;


function resultadoVotacion(){
    $sql="SELECT count(v.id) as votos, a.*
    FROM votacion v
    JOIN alumno a on v.id_delegado=a.id
    Group by a.id ";
    $query = $this->db->query($sql);
    return $query->getResult();
    }


    function detalleVotacion($id){
        $sql="SELECT a.nombre, a.apellido, v.fecha
        FROM votacion v
        JOIN alumno a on v.id_alumno=a.id
        WHERE v.id_delegado=$id ";
        $query = $this->db->query($sql);
        return $query->getResult();
        }

}