<?php
namespace App\Models;
use CodeIgniter\Model;
class alumnoRolModel extends Model
{
protected $table = 'alumno_rol';
protected $primaryKey = 'id';
protected $useAutoIncrement = true;
protected $returnType = 'object';
protected $useSoftDeletes = false;
protected $allowedFields = ['id_alumno','id_rol'];
protected bool $allowEmptyInserts = false;
protected bool $updateOnlyChanged = true;
}