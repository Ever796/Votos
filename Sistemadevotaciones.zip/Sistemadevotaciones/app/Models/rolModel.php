<?php

namespace App\Models;

use CodeIgniter\Model;

class rolModel extends Model
{
    protected $table = 'rol';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'object';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['nombre'];
    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;
    
    function buscarAlumnoXRol($rol)
    {
        $sql = "SELECT a.*, ar.id as id_alumno_rol
    FROM rol r
    JOIN alumno_rol ar on ar.id_rol=r.id
    JOIN alumno a on ar.id_alumno=a.id
    WHERE r.nombre = '$rol' ";
        $query = $this->db->query($sql);
        return $query->getResult();
    }
}
